// camera.js
Page({
  onReady() {

  },

})